Put a jpg file  with name logo.jpg 
Dimensions = 144 * 144

- Sample project creating something new and awesome